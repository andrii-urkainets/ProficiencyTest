import {
    PXScreen,
    graphInfo,
    createSingle,
    createCollection,
    PXView,
    PXFieldState,
    PXFieldOptions,
    GridPreset,
    gridConfig,
    viewInfo,
} from "client-controls";

@graphInfo({
    graphType: "ProficiencyTest.SOOrderManagementMaint",
    primaryView: "Document",
})
export class SO303010 extends PXScreen {
    @viewInfo({ containerName: "Order Management" })
    Document = createSingle(SOOrderManagement);

    @viewInfo({ containerName: "SO Order Info" })
    SalesOrders = createCollection(SalesOrder);

    @viewInfo({ containerName: "Detail Info" })
    SalesOrderLines = createCollection(SalesOrderLine);

    @viewInfo({ containerName: "Customer Info" })
    Customers = createSingle(Customer);

    @viewInfo({ containerName: "Customer Address" })
    CustomerAddresses = createSingle(CustomerAddress);

    @viewInfo({ containerName: "Customer Contact" })
    CustomerContacts = createSingle(CustomerContact);
}

export class SOOrderManagement extends PXView {
    OrderType: PXFieldState<PXFieldOptions.CommitChanges>;
    CustomerID: PXFieldState<PXFieldOptions.CommitChanges>;
    Description: PXFieldState;
    CurrentOrderNbr: PXFieldState<PXFieldOptions.Disabled>;
}

@gridConfig({
    preset: GridPreset.Details,
    allowInsert: false,
    allowUpdate: false,
    syncPosition: true,
    autoRepaint: ["Document"],
})
export class SalesOrder extends PXView {
    OrderNbr: PXFieldState;
    OrderType: PXFieldState;
    OrderTotal: PXFieldState;
}

@gridConfig({
    preset: GridPreset.Details,
    allowInsert: false,
    allowUpdate: false,
    initNewRow: true,
})
export class SalesOrderLine extends PXView {
    InventoryID : PXFieldState; 
    SiteID : PXFieldState;
    OrderQty : PXFieldState;
    UnitPrice : PXFieldState;
    UOM: PXFieldState;
}

@gridConfig({
    preset: GridPreset.Details
})
export class Customer extends PXView {
    LegalName: PXFieldState;
}

@gridConfig({
    preset: GridPreset.Details
})
export class CustomerAddress extends PXView {
    AddressLine1: PXFieldState;
    AddressLine2: PXFieldState;
    City: PXFieldState;
    State: PXFieldState;
    PostalCode: PXFieldState;
    CountryID: PXFieldState;
}

@gridConfig({
    preset: GridPreset.Details
})
export class CustomerContact extends PXView {
    Phone1Type: PXFieldState;
    Phone1: PXFieldState;
    Phone2Type: PXFieldState;
    Phone2: PXFieldState;
    Phone3Type: PXFieldState;
    Phone3: PXFieldState;
    EMail: PXFieldState;
    WebSite: PXFieldState;
}
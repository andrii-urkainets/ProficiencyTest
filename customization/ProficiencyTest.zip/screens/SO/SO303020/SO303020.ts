import { PXScreen, graphInfo, createCollection, PXView, PXFieldState, PXFieldOptions, gridConfig, columnConfig, GridPreset, QpGridEventArgs } from "client-controls";

@graphInfo({
  graphType: "ProficiencyTest.SOSalesTargetMaint",
  primaryView: "Targets"
})
export class SO303020 extends PXScreen {
  Targets = createCollection(SOSalesTarget);

  onGetCellEditorType(args: QpGridEventArgs) {
    if (args.activeColumn?.field !== "Command")
      return undefined;

    const typeColumn = args.grid.getColumn("TypeOfCommand");
    const typeCell = args.grid.getCell(typeColumn, args.activeRow);
    const typeValue = args.grid.getTypedCellValue(typeCell, typeColumn);

    if (typeValue === "M")
      return "qp-check-box";
    if (typeValue === "S")
      return "qp-datetime-edit";

    return undefined;
  }
}

@gridConfig({
  preset: GridPreset.Primary,
  allowInsert: false,
})
export class SOSalesTarget extends PXView {
  InventoryID: PXFieldState;
  SiteID: PXFieldState;
  OrderQty: PXFieldState;
  UnitPrice: PXFieldState;
  TypeOfCommand: PXFieldState<PXFieldOptions.CommitChanges>;

  @columnConfig({ fullState: true })
  Command: PXFieldState;
}
import { PXScreen, graphInfo, createCollection, PXView, PXFieldState, gridConfig, GridPreset } from "client-controls"; 

@graphInfo({ 
  graphType: "ProficiencyTest.SOSalesTargetMaint", 
  primaryView: "Targets" 
}) 
export class SO303020 extends PXScreen { 
  Targets = createCollection(SOSalesTarget); 
} 

@gridConfig({ 
  preset: GridPreset.Primary,
  allowInsert: false,
}) 
export class SOSalesTarget extends PXView { 
  InventoryID: PXFieldState;
  SiteID: PXFieldState; 
  OrderQty: PXFieldState; 
  UnitPrice: PXFieldState;
  TypeOfCommand: PXFieldState;
  ManualCommand: PXFieldState;
  ScheduledCommand: PXFieldState;
}
<%@ Page Language="C#" MasterPageFile="~/MasterPages/ListView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="SO303020.aspx.cs" Inherits="Page_SO303020" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/ListView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="ProficiencyTest.SOSalesTargetMaint"
        PrimaryView="Targets"
        >
		<CallbackCommands>

		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phL" runat="Server">
	<px:PXGrid ID="grid" runat="server" DataSourceID="ds" Width="100%" Height="150px" SkinID="Primary" AllowAutoHide="false">
		<Levels>
			<px:PXGridLevel DataMember="Targets">
			    <Columns>
			        <px:PXGridColumn DataField="InventoryID" />
			        <px:PXGridColumn DataField="SiteID" />
			        <px:PXGridColumn DataField="OrderQty" />
			        <px:PXGridColumn DataField="UnitPrice" />
			        <px:PXGridColumn DataField="TypeOfCommand" CommitChanges="True" />
			        <px:PXGridColumn DataField="Command" />
			    </Columns>
			</px:PXGridLevel>
		</Levels>
		<AutoSize Container="Window" Enabled="True" MinHeight="150" />
		<ActionBar >
		</ActionBar>
	</px:PXGrid>
</asp:Content>
